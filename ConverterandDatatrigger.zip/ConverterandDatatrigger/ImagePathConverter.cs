﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace ConverterandDatatrigger
{
    public enum GenderType
    {
        Male,
        Female,
        Other
    }

    public class ImagePathConverter:IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string path = string.Empty;

            if (value != null)
            {
                var gender = (GenderType)value;
                
                switch (gender)
                {
                    case GenderType.Male:
                        path = "Male";
                        break;
                    case GenderType.Female:
                        path = "Female";
                        break;
                    case GenderType.Other:
                        path = "Other";
                        break;
                    default:
                        break;
                }

            }

            return path;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class ImageIconConverter:IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            DrawingImage returnColourString = null;

            if (value != null)
            {
                var gender = (GenderType)value;

                switch (gender)
                {
                    case GenderType.Male:
                        returnColourString = Application.Current.TryFindResource("TestImage") as DrawingImage;
                        break;
                    case GenderType.Female:
                        returnColourString = Application.Current.TryFindResource("TestImage1") as DrawingImage;
                        break;
                    case GenderType.Other:
                        returnColourString = Application.Current.TryFindResource("TestImage2") as DrawingImage;
                        break;
                    default:
                        break;
                }
            }

           return returnColourString;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
