﻿namespace ConverterandDatatrigger
{
    public class Person
    {
        public GenderType Gender { get; set; }
    }
}
