﻿using System.Windows;
using System.Windows.Controls;

namespace ConverterandDatatrigger
{
    /// <summary>
    /// Interaction logic for ImageConverter.xaml
    /// </summary>
    public partial class ImageConverter : Window
    {
        public ImageConverter()
        {
            InitializeComponent();
            Image.DataContext = new Person() { Gender = GenderType.Male /*GenderType.Female or GenderType.Other*/ };
        }
    }
}
