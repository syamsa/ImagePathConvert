﻿using System.Windows;
using System.Windows.Controls;

namespace ConverterandDatatrigger
{
    /// <summary>
    /// Interaction logic for DataTrigger.xaml
    /// </summary>
    public partial class DataTrigger : Window
    {
        public DataTrigger()
        {
            InitializeComponent();
            Image.DataContext = new Person() { Gender = GenderType.Male /*GenderType.Other or GenderType.Other*/ };
        }
    }
}
